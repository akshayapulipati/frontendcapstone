import React, { useState } from 'react';
import HomeNavbar from "./HomeNavbar";
import { NavLink } from "react-router-dom";
import SideBar from "./SideBar";
import Salary from './Salary';
import './Home.css';  // Import your custom styles
import { Link } from 'react-router-dom';
import DocumentCenter from './DocumentCenter';
import Chatbot from './Chatbot';


function Home() {
  const [selectedOption, setSelectedOption] = useState('payslip');

  // Sample data
  const paySlipData = {
    salary: '',
    dateFrom: '',
    dateTo: '',
    status: 'Paid',
  };

  const documentData = {
    title: 'Important Document',
    description: 'This document contains important information.',
    creationDate: '2023-01-20',
  };

  function handleOptionChange(option) {
    setSelectedOption(option);
  }

  return (
    <div className="flex h-screen bg-gray-100"> {/* Use the entire height of the screen and set background color */}
      <SideBar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <div><HomeNavbar /></div>
        <Chatbot />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
          <div className="container mx-auto px-6 py-8">
            <h1 className="text-2xl font-semibold text-gray-800">Welcome to Your Home</h1>

            <div className="flex mt-8">
              <Link to="/salary">
                <button onClick={() => handleOptionChange('payslip')} className={`mr-2 py-2 px-4 rounded focus:outline-none ${selectedOption === 'payslip' ? 'bg-blue-500 text-white' : 'bg-gray-300 text-gray-800'}`}>
                  Pay Slip
                </button>
              </Link>
              <Link to="/documentcenter">
                <button onClick={() => handleOptionChange('document')} className={`py-2 px-4 rounded focus:outline-none ${selectedOption === 'document' ? 'bg-blue-500 text-white' : 'bg-gray-300 text-gray-800'}`}>
                  Document
                </button>
              </Link>
            </div>

            {selectedOption === 'payslip' && (
              <div className="mt-8 p-6 bg-white border rounded shadow-md">
                <img src="https://media.istockphoto.com/id/1323028878/vector/male-character-is-standing-next-to-bill-and-credit-reciept-debit-card-payment.jpg?s=612x612&w=0&k=20&c=17aOQAaCaJLPIOsz5wi-A37TwOh30GiMS8P91fkBJsw=" alt="Pay Slip" className="mb-4" />
                <h2 className="text-xl font-semibold text-gray-800">Pay Slip</h2>
                <p className="text-gray-600">Salary: ${paySlipData.salary}</p>
                <p className="text-gray-600">Date From: {paySlipData.dateFrom}</p>
                <p className="text-gray-600">Date To: {paySlipData.dateTo}</p>
                <p className="text-gray-600">Status: {paySlipData.status}</p>
              </div>
            )}

            {selectedOption === 'document' && (
              <div className="mt-8 p-6 bg-white border rounded shadow-md">
                <h2 className="text-xl font-semibold text-gray-800">{documentData.title}</h2>
                <p className="text-gray-600">Description: {documentData.description}</p>
                <p className="text-gray-600">Creation Date: {documentData.creationDate}</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default Home;
