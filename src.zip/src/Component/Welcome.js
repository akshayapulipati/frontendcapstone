import React from "react";
import MainNavbar from "./MainNavbar";
import Payrollfooter from "./PayrollFooter";
 
function Welcome() {
    return (
        <section class="pt-2 bg-white">
            <div><MainNavbar /></div>
            <div class="px-12 mx-auto max-w-7xl">
                <div class="w-full mx-auto text-left md:w-11/12 xl:w-9/12 md:text-center">
                    <h1 class="mb-6 text-4xl font-extrabold leading-none tracking-normal text-gray-900 md:text-6xl md:tracking-tight">
                        <span></span><br /> <span class="block w-full py-22 text-transparent bg-clip-text leading-12 bg-gradient-to-r from-green-400 to-purple-500 lg:inline">Payroll Management System</span> <span></span>
                    </h1>
                    <p class="px-0 mb-8 text-lg text-gray-600 md:text-xl lg:px-24">
                        Pay Fairly. Stay Compliant. Prevent Fraud
                    </p>
 
                </div>
               
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div style={{ flex: 1, }}>
                        {/* Your text content goes here */}
                        <img src="https://www.softwaresuggest.com/blog/wp-content/uploads/2019/01/payroll.png" alt="Description" style={{ maxWidth: '100%', height: 'auto', borderRadius: '8px' }} />
 
 
                    </div>
                    <div style={{ flex: 1, }}>
                        {/* Your image goes here */}
                        <center><h2><b>Payroll Management</b></h2><p>A payroll management system describes the specialist software that can empower companies by streamlining and automatically carrying out the processes involved in payroll such as working out take home pay and taxes – saving time for the employer and reducing the number of errors.</p></center>
                    </div>
                </div><br></br>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div style={{ flex: 1, }}>
                        {/* Your image goes here */}
                        <center>
                            <h2><b>Health Care </b></h2>
                            <br></br>
                            <p><b>Seamlessly delivering end-to-end digital health experiences</b></p>
                            <br></br><p>The future of healthcare is in digitally reimagined experiences for patients and caregivers alike. Digitalization offers increased choice and convenience for patients, and improved outcomes for caregivers while reducing costs and workloads.</p></center>
                    </div>
                    <div style={{ flex: 1, }}>
                        {/* Your text content goes here */}
                        <img src="https://bsmedia.business-standard.com/_media/bs/img/article/2023-07/04/full/1688489969-0188.jpg?im=FeatureCrop,size=(826,465)" alt="Description" style={{ maxWidth: '100%', height: 'auto', borderRadius: '10px' }} />
                    </div>
 
                </div><br></br>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div style={{ flex: 1, }}>
                        {/* Your text content goes here */}
                        <img src="https://www.cloudanalogy.com/wp-content/uploads/2019/09/banking-banner-min.png" alt="Description" style={{ maxWidth: '100%', height: 'auto', borderRadius: '8px' }} />
 
 
                    </div>
                    <div style={{ flex: 1, }}>
                        {/* Your image goes here */}
                        <center><h2><b>Banking & Finance</b></h2><b><p>Driving transformation with our banking, financial services, insurance, and payments experts.</p></b><p>We help Financial Services companies meet rapidly changing customer expectations, exploit disruptive business models and new technologies, become more efficient and resilient, and navigate uncertainty, risks and regulations.
 
                            We deliver this with our “NextGen” services which are unshackled from legacy thinking, processes or mindsets and achieves full stack transformation with Domain, Digital, Experience Design, DevOps, Platforms and AI/ML.</p></center>
                    </div>
                </div><br></br>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div style={{ flex: 1, }}>
                        {/* Your image goes here */}
                        <center>
                            <h2><b>Telecom</b></h2>
                            <br></br>
                            <p><b>TELECOM
                                Next-gen digital platforms and differentiated offerings for 5G technologies</b></p>
                            <br></br><p>If you’re looking for a trusted and reliable partner for your telecom IT services, look no further. We are uniquely aligned to serve our telecom domain customers as a strategic transformational partner through exclusive focus on Next-gen digital platforms and differentiated offerings for 5G technologies.</p></center>
                    </div>
                    <div style={{ flex: 1, }}>
                        {/* Your text content goes here */}
                        <img src="https://imageio.forbes.com/specials-images/imageserve/6392dc11b281ad3f3f8465eb/0x0.jpg?format=jpg&height=900&width=1600&fit=bounds" alt="Description" style={{ maxWidth: '100%', height: 'auto', borderRadius: '8px' }} />
                    </div>
 
                </div><br></br>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div style={{ flex: 1, }}>
                        {/* Your text content goes here */}
                        <img src="https://dldmuionqjz51.cloudfront.net/wp-content/uploads/2019/10/Hi-Tech-Platforms-Information-Services.jpg" alt="Description" style={{ maxWidth: '100%', height: 'auto', borderRadius: '8px' }} />
 
 
                    </div>
                    <div style={{ flex: 1, }}>
                        {/* Your image goes here */}
                        <center><h2><b>High-Technology</b></h2><b><p>HIGH TECHNOLOGY
                            Solving real world challenges through rapid innovation and cutting-edge R&D
                        </p></b><p>Companies that effectively turn digital transformation into business reality win. Period. With a team of experts and years of experience, we have developed a deep understanding of the unique challenges faced by companies in this dynamic and fast-paced industry.</p></center>
                    </div>
                </div><br></br>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div style={{ flex: 1, }}><br></br>
                        {/* Your image goes here */}
                        <center>
                            <h2><b>Media & Entertainment</b></h2>
                           
                            <p><b>
                                MEDIA & ENTERTAINMENT
                                Bringing our clients secure, seamless, and advanced enterprise messaging</b></p>
                            <br></br><p>The media and entertainment landscape is rapidly changing …. consumers are changing how they engage and access content, and companies are reinventing themselves to adopt new business models and generate new revenue streams. We develop purpose-built solutions for the media and entertainment market to help them navigate and success.</p></center>
                    </div>
                    <div style={{ flex: 1, }}>
                        {/* Your text content goes here */}
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbJGPqKCoiTw0x_3qk4cvqMKounh39n9EWbA&usqp=CAU" alt="Description" style={{ maxWidth: '200%', height: '200', borderRadius: '8px' }} />
                    </div>
 
                </div><br></br>
            </div>
            <Payrollfooter />
        </section>
 
    )
}
export default Welcome