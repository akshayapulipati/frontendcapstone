import React from "react";
import CANavbar from "./CANavbar";
import "./About.css"
function About(){
return(
    <div>
        <CANavbar/>
        <div class="flex-1 p-8">
        <div className="image-container"></div>
        <div className="content-container"></div>
        <h1>About Us</h1>
      <section>
        <h2><strong>Our Mission</strong></h2>
        <p>
          At Infinite, we understand the significance of efficient payroll management.
          Our mission is to simplify and streamline the payroll process for businesses of all sizes,
          ensuring accuracy, compliance, and time-saving solutions.
        </p>
      </section>
      <section>
        <h2><strong>Features</strong></h2>
        <p>
        <ul>
          <li>
            <strong>User-Friendly Interface:</strong> Navigate seamlessly through our intuitive
            React-based interface.
          </li>
          <li>
            <strong>Secure Data Handling:</strong> Your payroll data is encrypted and handled with
            the utmost security.
          </li>
          <li>
            <strong>Automated Calculations:</strong> Save time with automated payroll calculations,
            reducing errors.
          </li>
          <li>
            <strong>Compliance Assurance:</strong> Stay compliant with tax regulations and payroll
            laws effortlessly.
          </li>
        </ul>
        </p>
      </section>
      <section>
        <h2><strong>Contact Us</strong></h2>
        <p>
        Have questions or feedback? We'd love to hear from you! Reach out to us at
          <a href="Infinite@gmail.com"> Infinte@gmail.com</a> or visit our
          <a href="#support"> Infinite.com</a>.
        </p>
        </section>
     
      <center><p>*******Thank you for choosing Infinite for your payroll management needs!*******</p></center>
                </div>
    </div>
);
}
 
export default About