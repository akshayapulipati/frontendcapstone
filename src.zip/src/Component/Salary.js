import React, { useState } from "react";

import SideBar from "./SideBar";
import HomeNavbar from "./HomeNavbar";
import VerticalNavBar from "./VerticalNavBar";
function Salary() {
    const [selectedOption, setSelectedOption] = useState('salary');

    const salaryData = {
        basicSalary: '',
        bonuses: '',
        allowances: '',
    };

    const deductionData = {
        tax: '',
        insurance: '',
    };

    // Calculate net pay
    const calculateNetPay = () => {
        const totalEarnings = salaryData.basicSalary + salaryData.bonuses + salaryData.allowances;
        const totalDeductions = deductionData.tax + deductionData.insurance;
        return totalEarnings - totalDeductions;
    };
    // Calculate net pay
    const attendance = {
        empid : '',
        noofleaves : '',
        leavestaken : '',
        month :'',
        year :'',
    };

    const handleOptionChange = function (option) {
        setSelectedOption(option);
    };
    return (
        <div className="flex flex-col h-screen" >

            <div><HomeNavbar /></div>
            <div className="salary-container">
                <div className='flex flex-1'>

                    <SideBar />
                    <div className='flex flex-1'>
                        <div className="salary">
                            <div className="header">
                                <h1>Salary Details</h1>
                            </div>

                            <div className="options">

                                <button onClick={function () { handleOptionChange('salary'); }} className={selectedOption === 'salary' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                    Salary
                                </button>
                                <button onClick={function () { handleOptionChange('deduction'); }} className={selectedOption === 'deduction' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                    Deduction
                                </button>
                                <button onClick={function () { handleOptionChange('netpay'); }} className={selectedOption === 'netpay' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                    Net Pay
                                </button>
                                <button onClick={function () { handleOptionChange('attendance'); }} className={selectedOption === 'attendance' ? 'active' : ''} style={{ marginRight: '10px' }}>
                                    Attendance
                                </button>
                            </div>

                            {selectedOption === 'salary' && (
                                <div className="salary-details">
                                    <h2>Salary Details</h2>
                                    <p>Basic Salary: {salaryData.basicSalary}</p>
                                    <p>Bonuses: {salaryData.bonuses}</p>
                                    <p>Allowances: {salaryData.allowances}</p>
                                </div>
                            )}

                            {selectedOption === 'deduction' && (
                                <div className="deduction-details">
                                    <h2>Deduction Details</h2>
                                    <p>Tax: {deductionData.tax}</p>
                                    <p>Insurance: {deductionData.insurance}</p>
                                </div>
                            )}

                            {selectedOption === 'netpay' && (
                                <div className="netpay-details">
                                    <h2>Net Pay</h2>
                                    <p>Total Earnings: {calculateNetPay()}</p>
                                </div>
                            )}
                            {selectedOption === 'attendance' && (
                                <div className="attendance-details">
                                    <h2>Attendance</h2>
                                    <p>Emp id: {attendance.empid}</p>
                                    <p>No of Leaves: {attendance.noofleaves}</p>
                                    <p>Leaves taken: {attendance.leavestaken}</p>
                                    <p>Month: {attendance.month}</p>
                                    <p>Year: {attendance.year}</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Salary;







