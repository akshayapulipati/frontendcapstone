import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import LoginNavbar from "./LoginNavbar";

function Login() {
    const navigate = useNavigate();
    const [employeeId, setEmployeeId] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState({});
    
    function handleClick() {
        const validationErrors = validateInputs();
        if (Object.keys(validationErrors).length === 0) {
            navigate('/home');
        } else {
            setErrors(validationErrors);
        }
    }

    function validateInputs() {
        let validationErrors = {};

        if (!employeeId.trim()) {
            validationErrors.employeeId = "Employee ID is required";
        }

        if (!password.trim()) {
            validationErrors.password = "Password is required";
        }

        return validationErrors;
    }

    const sliderSettings = {
        dots: true,
        infinite: true,
        speed: 700,
        autoplay: true, 
        autoplaySpeed: 500, 
        slidesToShow: 1,
        slidesToScroll: 1
    };

    const images = [
        "https://media.istockphoto.com/id/1305286141/vector/paycheck-abstract-concept-vector-illustration.jpg?s=612x612&w=0&k=20&c=BMlzLkgLGLsNW2zJjJndezt3Nm0eneczYhC06BNkzDA=",
        "https://img.freepik.com/premium-vector/payroll-isolated-cartoon-vector-illustrations_107173-22006.jpg",
        // Add more image URLs as needed
    ];

    return (
        <div>
        <LoginNavbar/>
        <section className="bg-white dark:bg-gray-900">
            
            <div className="container px-6 py-12 mx-auto flex lg:flex-row-reverse">
                <div className="lg:w-1/2 lg:mx-6">
                    <Slider {...sliderSettings}>
                        {images.map((imageUrl, index) => (
                            <div key={index}>
                                <img
                                    src={imageUrl}
                                    alt={`Slide ${index + 1}`}
                                    className="w-full h-auto"
                                />
                            </div>
                        ))}
                    </Slider>
                </div>

                <div className="lg:w-1/2 lg:mx-6">
                    <div
                        className="w-full px-8 py-10 mx-auto overflow-hidden bg-white rounded-lg shadow-2xl dark:bg-gray-900 lg:max-w-xl shadow-gray-300/50 dark:shadow-black/50"
                    >
                        <h1 className="text-lg font-medium text-gray-700">Employee Login</h1>

                        <form className="mt-6">
                            <div className="flex-1">
                                <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Employee ID</label>
                                <input
                                    type="text"
                                    placeholder="Employee ID"
                                    className={`block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border ${errors.employeeId ? "border-red-500" : "border-gray-200"} rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40`}
                                    onChange={(e) => setEmployeeId(e.target.value)}
                                />
                                {errors.employeeId && (
                                    <p className="mt-1 text-xs text-red-500">{errors.employeeId}</p>
                                )}
                            </div>

                            <div className="flex-1 mt-6">
                                <label className="block mb-2 text-sm text-gray-600 dark:text-gray-200">Password</label>
                                <input
                                    type="password"
                                    placeholder="Password"
                                    className={`block w-full px-5 py-3 mt-2 text-gray-700 placeholder-gray-400 bg-white border ${errors.password ? "border-red-500" : "border-gray-200"} rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-blue-400 dark:focus:border-blue-400 focus:ring-blue-400 focus:outline-none focus:ring focus:ring-opacity-40`}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                                {errors.password && (
                                    <p className="mt-1 text-xs text-red-500">{errors.password}</p>
                                )}
                            </div>

                            <button
                                type="button"
                                className="w-full px-6 py-3 mt-6 text-sm font-medium tracking-wide text-white capitalize transition-colors duration-300 transform bg-blue-500 rounded-md hover:bg-blue-400 focus:outline-none focus:ring focus:ring-blue-300 focus:ring-opacity-50"
                                onClick={handleClick}
                            >
                                Login
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
        </section>
        </div>
    );
}

export default Login;
