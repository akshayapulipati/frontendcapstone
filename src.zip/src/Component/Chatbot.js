import React, { useState } from 'react';
import ChatBot from 'react-simple-chatbot';

const Chatbot = () => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [currentMonthSalary, setCurrentMonthSalary] = useState(null);
  const [previousMonthSalary, setPreviousMonthSalary] = useState(null);

  const fetchCurrentMonthSalary = () => {
    // Simulating an asynchronous API call with setTimeout
    setTimeout(() => {
      const salaryData = {
        salary: 5000,
        dateFrom: '2023-11-01',
        dateTo: '2023-11-30',
        status: 'Paid',
      };
      setCurrentMonthSalary(salaryData);
    }, 1000); // Simulate a delay of 1 second
  };

  const fetchPreviousMonthSalary = () => {
    // Simulating an asynchronous API call with setTimeout
    setTimeout(() => {
      const salaryData = {
        salary: 5000,
        dateFrom: '2023-10-01',
        dateTo: '2023-10-31',
        status: 'Paid',
      };
      setPreviousMonthSalary(salaryData);
    }, 1000); // Simulate a delay of 1 second
  };

  const fetchLeaveBalances = () => {
    // Simulating an asynchronous API call with setTimeout
    // Replace with an actual API call to fetch leave balances
    setTimeout(() => {
      // Simulating leave balance data
      console.log('Leave balance data fetched.');
    }, 1000); // Simulate a delay of 1 second
  };

  const steps = [
    {
      id: 'Greet',
      message: 'Hello! Welcome to our Payroll Management Chatbot.',
      trigger: 'AskEmployeeName',
    },
    {
      id: 'AskEmployeeName',
      message: 'To assist you, please enter your Name',
      trigger: 'WaitingEmployeeName',
    },
    {
      id: 'WaitingEmployeeName',
      user: true,
      trigger: 'AskIssue',
    },
    {
      id: 'AskIssue',
      message: `Hi {previousValue}, what can I help you with today?`,
      trigger: 'Issues',
    },
    {
      id: 'Issues',
      options: [
        { value: 'SalaryDetails', label: 'Salary Details', trigger: () => handleOptionSelect('SalaryDetails') },
        { value: 'LeaveBalances', label: 'Leave Balances', trigger: () => handleOptionSelect('LeaveBalances') },
        { value: 'TaxInformation', label: 'Tax Information', trigger: () => handleOptionSelect('TaxInformation') },
      ],
    },
    {
      id: 'SalaryDetails',
      message: `Sure, I can help you with your salary details. Please choose a specific option:`,
      trigger: 'SalaryOptions',
    },
    {
      id: 'SalaryOptions',
      options: [
        { value: 'CurrentMonth', label: 'Current Month Salary', trigger: 'CurrentMonthSalary' },
        { value: 'PreviousMonth', label: 'Previous Month Salary', trigger: 'PreviousMonthSalary' },
      
        // Add more options as needed
      ],
    },
    {
      id: 'CurrentMonthSalary',
      message: 'Your salary details for the current month are being processed. Please wait...',
      trigger: 'FetchCurrentMonthSalary',
    },
    {
      id: 'FetchCurrentMonthSalary',
      component: (
        <div>
          {fetchCurrentMonthSalary()} {/* Simulate API call */}
        </div>
      ),
      trigger: 'ProvideCurrentMonthSalary',
    },
    {
      id: 'ProvideCurrentMonthSalary',
      component: (
        <div>
          <p>Your salary details for the current month:</p>
          <ul>
            <li>Salary: ${currentMonthSalary?.salary}</li>
            <li>Date From: {currentMonthSalary?.dateFrom}</li>
            <li>Date To: {currentMonthSalary?.dateTo}</li>
            <li>Status: {currentMonthSalary?.status}</li>
          </ul>
        </div>
      ),
      end: true,
    },
    {
      id: 'PreviousMonthSalary',
      message: 'Your salary details for the previous month are being processed. Please wait...',
      trigger: 'FetchPreviousMonthSalary',
    },
    {
      id: 'FetchPreviousMonthSalary',
      component: (
        <div>
          {fetchPreviousMonthSalary()} {/* Simulate API call */}
        </div>
      ),
      trigger: 'ProvidePreviousMonthSalary',
    },
    {
      id: 'ProvidePreviousMonthSalary',
      component: (
        <div>
          <p>Your salary details for the previous month:</p>
          <ul>
            <li>Salary: ${previousMonthSalary?.salary}</li>
            <li>Date From: {previousMonthSalary?.dateFrom}</li>
            <li>Date To: {previousMonthSalary?.dateTo}</li>
            <li>Status: {previousMonthSalary?.status}</li>
          </ul>
        </div>
      ),
      end: true,
    },
    
    {
      id: 'LeaveBalances',
      message: 'Sure, let me check your leave balances. Please wait...',
      trigger: 'FetchLeaveBalances',
    },
    {
      id: 'FetchLeaveBalances',
      component: (
        <div>
          {fetchLeaveBalances()} {/* Simulate API call */}
        </div>
      ),
      trigger: 'ProvideLeaveBalances',
    },
    {
      id: 'ProvideLeaveBalances',
      message: 'Your current leave balance is 15 days.', // Replace with actual data from the backend
      end: true,
    },
    {
      id: 'TaxInformation',
      message: 'Sure, I can help you with your tax information. Please choose a specific option:',
      trigger: 'TaxOptions',
    },
    {
      id: 'TaxOptions',
      options: [
        { value: 'CurrentYearTax', label: 'Current Year Tax Details', trigger: 'CurrentYearTaxDetails' },
        { value: 'PreviousYearTax', label: 'Previous Year Tax Details', trigger: 'PreviousYearTaxDetails' },
        // Add more options as needed
      ],
    },
    {
      id: 'CurrentYearTaxDetails',
      message: 'Your current year tax details are being processed. Please wait...',
      end: true,
    },
    {
      id: 'PreviousYearTaxDetails',
      message: 'Your previous year tax details are being processed. Please wait...',
      end: true,
    },
    // Add more steps for additional features
  ];

  const handleOptionSelect = (option) => {
    setSelectedOption(option);
    return option;
  };
  

  return (
    <ChatBot
      steps={steps}
      floating={true}
      cache={false}
      opened={selectedOption !== null}
    />
  );
};

export default Chatbot;
