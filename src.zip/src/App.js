import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route,Routes, Switch } from 'react-router-dom';
import Login from './Component/Login';
import Info from './Component/Info';
import Home from './Component/Home';
import Welcome from './Component/Welcome';
import Register from './Component/Register';
import Salary from './Component/Salary';
import DocumentCenter from './Component/DocumentCenter';
import Settings from './Component/Settings';
import Help from './Component/Help';

import PFCalculator from './Component/PFCalculator.js';
import About from './Component/About';
import React, { useEffect } from 'react';



function App() {
  useEffect(function () {
    function disableBackButton(e) {
      // Prevent going back in history
      window.history.forward();
    }
 
    // Attach the event listener when the component mounts
    window.addEventListener('popstate', disableBackButton);
 
    // Clean up the event listener when the component unmounts
    return function () {
      window.removeEventListener('popstate', disableBackButton);
    };
  }, []); // Empty
  return (
    <>
      <Routes>

        <Route path='/' element={<Welcome />} />
        <Route path='Register' element={<Register />} />
        <Route path='/home' element={<Home />} />
        <Route path='/info' element={<Info />} />
        <Route path='/login' element={<Login />} />
        <Route path='/salary' element={<Salary />} />
        <Route path='/documentcenter' element={<DocumentCenter />} />
        <Route path='/settings' element={<Settings />} />
        <Route path='/help' element={<Help />} />
        <Route path='/calculator' element={<PFCalculator />} />
        <Route path='/About' element={<About />} />
        
      </Routes>
     

      <div >
      </div>
    </>
  );
}

export default App;